<?php
require_once './connection.php';
if(empty($_SESSION['user_id']))
{
	echo "<script>window.location.href='index.php'</script>";
}

?>

<!DOCTYPE html>
<html lang="en-US">



<head>
    <title>Foodshala | Add Menu Item</title>
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7Chttps://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7CPoppins:300i,300,400,700,400i,500%7CDancing+Script:700%7CDancing+Script:700" rel="stylesheet">
    <!-- animate -->
    <link rel="stylesheet" href="assets/css/animate.css" />
    <!-- owl Carousel assets -->
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- hover anmation -->
    <link rel="stylesheet" href="assets/css/hover-min.css">
    <!-- flag icon -->
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <!-- main style -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- jquery library  -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
	


</head>

<body>

    <?php include('header.php')?>
    <!-- // Header  -->
<section class="banner padding-tb-20px sm-ptb-80px background-overlay" >
	<div class=" kt-grid kt-grid--ver kt-grid--root kt-page container z-index-2 position-relative">
		<div class="kt-grid kt-grid--hor kt-grid--root  kt-login kt-login--v1" id="kt_login">
				<div class="kt-login__body" id="e_pf">

				<!--begin::Signin-->
				<div class="kt-portlet">
					
					<!--begin::Form-->
					<form name="add_menu" action="add_menu_item_Ctrl.php" method="POST" enctype="multipart/form-data" class="kt-form margin-top-70px" id="add_menu" >
						<div class="kt-portlet__body">
							<div class="kt-section kt-section--first">
							<label class="col-lg-10 col-form-label text-center"><h2><b><u><i>Add Menu Item</i></u></h2></b></label>
								<div class="kt-section__body margin-top-30px">
								
									<div class="form-group row">
										<label class="col-lg-24 col-form-label padding-left-300px"><b>Food Name:</b></label>
										<div class="col-lg-4" id="name_div">
											<input type="text" class="form-control" name="menu_name" placeholder="" required>
											<div id="name_error"></div>
											
										</div>
									</div>
									
									
									
									<div class="form-group row">
										<label class="col-lg-24 col-form-label padding-left-300px"><b/>Upload Photo:</label>
										<div class="col-lg-4">
										<div class="file-upload-wrapper">
											<input type="file" name="dp" id="input-file-now" class="file-upload" />
										</div>
											
										</div>
									</div>
									
									<div class="form-group"  >
										<label class="col-lg-24 padding-left-300px col-form-label">Food Type:</label>
										<div class="col-6 padding-left-290px col-form-label">
											<div class="kt-radio-inline">
												<label class="kt-radio">
													<input type="radio" name="radio4" checked value="0" > Veg
													<span></span>
												</label>
												<label class="kt-radio">
													<input type="radio" name="radio4" value="1" > Non-Veg
													<span></span>
												</label>
											</div>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-lg-24 col-form-label padding-left-300px"><b>Price</b></label>
										<div class="col-lg-4" id="price_div">
											<input type="text" class="form-control" id="price" name="price" required>
											<div id="price_error"></div>
											
										</div>
									</div>
									
									
									
								</div>
							</div>
						</div>
						<div class="kt-portlet__foot">
							<div class="kt-form__actions">
								<div class="row">
									<div class="col-lg-3"></div>
									<div class="col-lg-6">
										<button type="submit" name="submit" class="btn btn-success margin-left-100px">Submit</button>
										<button type="reset" class="btn btn-secondary margin-left-30px">Cancel</button>
									</div>
								</div>
							</div>
						</div>
						
					</form>
					<!--end::Form-->
				</div>
				
				<!--end::Signin-->
			</div>
			<!--end::Content-->
		</div>
	
</div>
</section>

	
<!-- end:: Page -->
			
			<!--begin:: Global Mandatory Vendors -->
			<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>


	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js" integrity="sha256-sPB0F50YUDK0otDnsfNHawYmA5M0pjjUf4TvRJkGFrI=" crossorigin="anonymous"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js" integrity="sha256-3blsJd4Hli/7wCQ+bmgXfOdK7p/ZUMtPXY08jmxSSgk=" crossorigin="anonymous"></script>
	
<!--end:: Global Mandatory Vendors -->

<!--custom js ends-->

    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/imagesloaded.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/jquery-3.2.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js" integrity="sha256-3blsJd4Hli/7wCQ+bmgXfOdK7p/ZUMtPXY08jmxSSgk=" crossorigin="anonymous"></script>
	<script type="text/javascript">


        $('#price').bind('keyup paste', function(){
            this.value = this.value.replace(/[^0-9\.]/g, '');
        });
		$("#add_menu").validate({
			rules: {
				radio4: {
				  required: true,
				},
				menu_name: {
				  	required: true,
				},
				price: {
					required: true,
					number: true,
                    maxlength: 7,
                    minlength: 1
				},
			},
		    messages: {
		        menu_name: {
		          required: "Please provide a menu name"
		        },
		        price: {
		          required: "Please provide a price"
		        }
		    },
			errorPlacement: function(label, element) {
				//$('input').css("color", "red");
                //$('input').css("border", "1px solid red");
			},
			highlight: function(element, errorClass) {
				$(element).addClass('has-error');
				$(element).addClass('error');
			},
			unhighlight: function(element, errorClass, validClass) {
				$(element).removeClass('has-error');
				$(element).removeClass('error');
			},
			/*submitHandler: function(form) {
				//var data = $('#add_menu').serialize();
                var action = $('#add_menu').attr('action');
				var form = $('#add_menu')[0];
				var data = new FormData(form);
				$.ajax({
					url:action,
					type: "POST",
					data: data,
					dataType: "json",
					success: function(result){
						if(result.error == 0){
							toastr.success('Menu added successfully!'); 
							setTimeout(function(){ 
							window.location.replace("menu.php");
							}, 2000);
							}else{
							alert("Wrong Cradential !");
							//toastr.error('Wrong Cradential !');
						}
                    },
                    error: function(error){
                        console.log(error.responseText);
                    }
				});
			}*/
		});
    </script>
</body>
</html>