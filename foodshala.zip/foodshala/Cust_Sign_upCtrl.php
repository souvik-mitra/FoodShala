<?php
require_once './connection.php';

if(isset($_POST["submit"]))
{
	$name=$_POST["full_name"];
	$address=$_POST["address"];
	$email=$_POST["email"];
	$phone_no=$_POST["ph_no"];
	$password=$_POST["password"];
	$preference=$_POST["radio4"];
	$phone_no_check=mysqli_query($con, "select * from tbl_cust_reg where phone_no='".$phone_no."' ");
	$count_ph_no = mysqli_num_rows($phone_no_check);
	if($count_ph_no > 0)
	{
		header("Location: sign_up_choose.php");
	}else{
		$insert = mysqli_query($con, "insert into tbl_cust_reg(name,phone_no,email,address,preference)values('".$name."','".$phone_no."','".$email."','".$address."','".$preference."')"); 
		$id = mysqli_insert_id($con);
	}
	//enter data for login page
	if($insert){  
		$insert2 = mysqli_query($con, "insert into tbl_login(fk_user_id,username,password,user_type)values('".$id."','".$phone_no."','".$password."','C')"); 
		if($insert2){
			header("Location: login.php");
		}
	}
	
	



}

?>