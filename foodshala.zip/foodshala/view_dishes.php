<?php
require_once './connection.php';
$rest_id = $_GET['id'];

$qry = mysqli_query($con,"SELECT * FROM tbl_rest_reg WHERE id='".$rest_id."'");
$row = mysqli_fetch_assoc($qry);
if($row['photo']=='' || $row['photo']==null)
{
	$img = 'image_upload/a.jpg';
}else{
	$img = 'image_upload/'.$row['photo'];
}
if(isset($_SESSION['user_type'])){
	if($_SESSION['user_type'] == 'C'){
		$qry9 = mysqli_query($con, "SELECT preference FROM tbl_cust_reg WHERE id = '".$_SESSION['user_id']."'");
		$data9 = mysqli_fetch_assoc($qry9);
		if($data9['preference'] == 0){
			$qry10 = "SELECT * FROM tbl_add_menu WHERE fk_rest_id='".$rest_id."' AND menu_type =0 ";
		}else if($data9['preference'] == 1){
			$qry10 = "SELECT * FROM tbl_add_menu WHERE fk_rest_id='".$rest_id."' AND menu_type = 1 ";
		}else{
			$qry10 = "SELECT * FROM tbl_add_menu WHERE fk_rest_id='".$rest_id."' ";
		}
	}else{
		$qry10 = "SELECT * FROM tbl_add_menu WHERE fk_rest_id='".$rest_id."' ";
	}
}else{
	$qry10 = "SELECT * FROM tbl_add_menu WHERE fk_rest_id='".$rest_id."' ";
}
$qry2 = mysqli_query($con,$qry10);
?>

<!DOCTYPE html>
<html lang="en-US">


<head>
    <title>Foodshala | View Dishes</title>
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7Chttps://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7CPoppins:300i,300,400,700,400i,500%7CDancing+Script:700%7CDancing+Script:700" rel="stylesheet">
    <!-- owl Carousel assets -->
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- hover anmation -->
    <link rel="stylesheet" href="assets/css/hover-min.css">
    <!-- main style -->
    <link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" integrity="sha256-ENFZrbVzylNbgnXx0n3I1g//2WeO47XxoPe0vkp3NC8=" crossorigin="anonymous" />		
</head>

<body>

    <?php include('header.php')?>
    <!-- // Header  -->
	
    <section class="banner padding-tb-200px sm-ptb-80px background-overlay" >
        <div class="container z-index-2 position-relative">
			<div class="row" id="info_div ">
                <div class="col-lg-12 sm-mb-45px padding-top-50px padding-left-170px">
                    <div class="background-white thum-hover box-shadow hvr-float full-width margin-bottom-45px">
                        <div class="float-lg-left margin-right-30px sm-mr-0px text-center sm-mt-35px">
                            <img src="<?php echo $img;?>" class="img-rounded" width="265" height="230" alt="">
                        </div>
                        <div class="padding-lr-25px padding-tb-25px">
                            <a class="d-block text-dark text-medium margin-bottom-5px" href="#"><?php echo $row['name'];?></a>
							<a class="d-block text-dark text-medium margin-bottom-5px" href="#">Address: <?php echo $row['address'];?></a>
                            <p class="margin-top-15px text-grey-2"><?php echo $row['description'];?></p>
                            
                        </div>
                        <div class="clearfix"></div>
						
						<div id="dish_div">
							
				
								<div  class=" row padding-top-20px ">
									<label class="col-lg-7 col-md-7 col-form-label padding-left-120px"><b><u>Available Dishes</u></b></label>
									<label class="col-lg-2 col-md-2 col-form-label padding-left-100px"><b><u>Quantity</u></b></label>
									<label class="col-lg-2 col-md-2 col-form-label padding-left-140px"><b><u>Price</u></b></label>
								</div>
								
								
								<?php 
									while($data = mysqli_fetch_assoc($qry2))
											{ 
												if($data['photo']=='' || $data['photo']==null)
												{
													$img = 'menu_upload/a.png';
												}else{
													$img = 'menu_upload/'.$data['photo'];
											}
								?>	
									<div  class="row padding-top-50px">
										<div class="col-lg-1 col-md-1 padding-left-50px padding-top-20px">
											<input type="checkbox" name="dish_item" class="dish_item" value="<?php echo $data['id'];?>">
										</div>
										<div class="float-lg-left padding-left-15px col-lg-2 col-md-2 sm-mr-0px text-center sm-mt-35px">
											<img src="<?php echo $img?>" class="img-rounded" width="60" height="60" alt="">
										</div>
										
										<div class="col-lg-4  padding-top-20px  col-md-4 ">
											<a class="text-dark text-medium margin-bottom-5px" href="#"><?php echo $data['menu_name'];?></a>
										</div>
										<div class="col-lg-2 col-md-2 padding-left-105px padding-top-20px test">
											<input type="text" class="form-control text-center amount" name="amount" value="1" maxlength="1" >
										</div>
										<div class="col-lg-2 col-md-2 padding-left-140px padding-top-20px ">
											<a class=" text-dark text-medium margin-bottom-5px" href="#"><?php echo $data['price'];?></a>
										</div>
										
									</div>
									<?php 
											} ?>
										
										
						</div>
							<?php if(isset($_SESSION['user_type'])){
									if($_SESSION['user_type'] != 'R'){?>
							<div class="row ">
                                <div class="col-lg-12 text-center padding-top-10px">
                                   <button class="btn btn-md border-0 border-radius-10 background-main-color padding-lr-20px text-white margin-tb-10px margin-bottom-30px"  id="order">Order Now</button>
                                </div>
                            </div>
							<?php } } ?>
					
							
						</div>
							<div class="clearfix"></div>
					
					</div>
			
				</div>
                    
                
            </div>
        </div>
                       
    </section>
			
	

 <?php include('footer.php')?>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>

    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/imagesloaded.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/custom.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js" integrity="sha256-3blsJd4Hli/7wCQ+bmgXfOdK7p/ZUMtPXY08jmxSSgk=" crossorigin="anonymous"></script>
	<script type="text/javascript">


        $('#amount').bind('keyup paste', function(){
            this.value = this.value.replace(/[^1-9]/g, '');
        });
		$("#order").on('click', function(){
            var menu_array = [];
			var qty_array = [];
            $.each($("input[name='dish_item']:checked"), function(){
                menu_array.push($(this).val());
				var qty = $(this).parent().parent().find("input[type=text]").val();
				qty_array.push(qty);
            });
			var action = 'order_Ctrl.php';
			if(menu_array.length > 0){
				$.ajax({
					type: 'POST',
					url: action,
					data: {menu_array:menu_array,qty_array:qty_array,submit:'submit'},
					dataType: "json",
					success: function(data){
						console.log(data);
						if(data.error == 0){
							toastr.success('order successfully added to cart '); 
							setTimeout(function(){ 
								window.location.replace("cart.php");
							}, 2000);
						}else{
							toastr.error('Internal server error'); 
						}
					}
				});
			}else{
				toastr.error('Please select atleast one dish!');
			}
        });
		//$('#order').
    </script>
	
    
	
</body>



</html>
