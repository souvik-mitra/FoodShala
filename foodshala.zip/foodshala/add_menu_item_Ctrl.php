<?php
require_once './connection.php';
if(isset($_POST["submit"]))
{
	$menu_name=$_POST["menu_name"];
	$menu_type=$_POST["radio4"];
	$price=$_POST["price"];
	$rest_id=$_SESSION["user_id"];
	
	$file_name = '';
		if(isset($_FILES['dp'])){
			if($_FILES['dp']['name'] != '')
			{
				$errors= array();
			$rand = rand(1000,9999);
			$file_name = $rand."_".$_FILES['dp']['name'];
			$file_size =$_FILES['dp']['size'];
			$file_tmp =$_FILES['dp']['tmp_name'];
			$file_type=$_FILES['dp']['type'];
			$exploded = explode('.', $_FILES['dp']['name']);
			$file_ext = strtolower(end($exploded));
		  
			$extensions= array("jpeg","jpg","png");
		  
			if(in_array($file_ext,$extensions)=== false){
				$errors[]="extension not allowed, please choose a JPEG or PNG file.";
			}
		  
			if($file_size > 2097152){
				$errors[]='File size must be excately 2 MB';
			}
		  
			if(empty($errors)==true){
				move_uploaded_file($file_tmp,"menu_upload/".$file_name);
			}
			}
			
		}
		
	$insert = mysqli_query($con, "insert into tbl_add_menu(menu_name,menu_type,photo,price,fk_rest_id)values('".$menu_name."','".$menu_type."','".$file_name."','".$price."','".$rest_id."')"); 
	
	if($insert){
		header("Location: add_menu_item.php");
	}
	
	
		
	
	
	



}

?>