<!DOCTYPE html>
<html lang="en-US">



<head>
    <title>Foodshala | Success</title>
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7Chttps://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7CPoppins:300i,300,400,700,400i,500%7CDancing+Script:700%7CDancing+Script:700" rel="stylesheet">
    <!-- animate -->
    <link rel="stylesheet" href="assets/css/animate.css" />
    <!-- owl Carousel assets -->
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- hover anmation -->
    <link rel="stylesheet" href="assets/css/hover-min.css">
    <!-- flag icon -->
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <!-- main style -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- colors -->
    <link rel="stylesheet" href="assets/css/colors/main.css">
    <!-- elegant icon -->
    <link rel="stylesheet" href="assets/css/elegant_icon.css">

    <!-- jquery library  -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <!-- fontawesome  -->
    <script defer src="../../../use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
	


</head>

<body>

    <?php include('header.php')?>
    <!-- // Header  -->
	<section class="banner padding-tb-200px sm-ptb-80px background-overlay" >
        <div class="container z-index-2 position-relative">
			<h2 class="text-title-large text-main-color font-weight-300 margin-bottom-15px padding-left-250px">Congratulation! Your order has been placed. Your food is being prepared.</h2>
		</div>
	</section>
	
	
	
	
	
	
	
	 <?php include('footer.php')?>
	<!--begin:: Global Mandatory Vendors -->
<script src="assets/vendors/general/js/jquery.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/popper.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/js.cookie.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/moment.min.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/tooltip.min.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/perfect-scrollbar.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/sticky.min.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/wNumb.js" type="text/javascript"></script>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js" integrity="sha256-sPB0F50YUDK0otDnsfNHawYmA5M0pjjUf4TvRJkGFrI=" crossorigin="anonymous"></script>
    <script src="assets/js/sticky-sidebar.js"></script>
    <script src="assets/js/YouTubePopUp.jquery.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/imagesloaded.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/jquery-3.4.1.min.js"></script>
	
</body>
</html>