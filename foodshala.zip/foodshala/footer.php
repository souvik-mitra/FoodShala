<footer class="padding-bottom-85px padding-top-30px background-main-color wow fadeInUp">
    <div class="container">
        <div class="row">
            <div class="col-lg-2">
                <a class="d-inline-block margin-tb-15px">Foodshala</a>
            </div>
            <div class="col-lg-4">
                <p class="text-white opacity-7">Feeling Hungry?.  .  .Order food online and get delivery at your doorstep . India's no 1 food delivery
				company.</p>
            </div>
            <div class="col-lg-6">
                <ul class="footer-menu margin-tb-15px margin-lr-0px padding-0px list-unstyled float-lg-right">
                    <li><a href="javascript:;" class="text-white">Featured</a></li>
                    <li><a href="javascript:;" class="text-white">Feedback</a></li>
                    <li><a href="javascript:;" class="text-white">Ask a Question</a></li>
                </ul>
            </div>
        </div>
        <hr class="border-white opacity-4">
        <div class="row">
            <div class="col-lg-6">
                <p class="margin-0px text-white opacity-7 sm-mb-15px">© <?php echo date('Y');?> All India Foodshala | All Right Reserved. </p>
            </div>
            <div class="col-lg-6">
                <ul class="social-icon style-2 float-lg-right">
                    <li class="list-inline-item"><a class="facebook" href="javascript:;"><i class="fab fa-facebook-f"></i></a></li>
                    <li class="list-inline-item"><a class="youtube" href="javascript:;"><i class="fab fa-youtube"></i></a></li>
                    <li class="list-inline-item"><a class="linkedin" href="javascript:;"><i class="fab fa-linkedin"></i></a></li>
                    <li class="list-inline-item"><a class="google" href="javascript:;"><i class="fab fa-google-plus"></i></a></li>
                    <li class="list-inline-item"><a class="twitter" href="javascript:;"><i class="fab fa-twitter"></i></a></li>
                    <li class="list-inline-item"><a class="rss" href="javascript:;"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>