<!DOCTYPE html>
<html lang="en" >
    <!-- begin::Head -->
    <head>

        <title>FoodShala | Login</title>

        <!--begin::Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700">        <!--end::Fonts -->

        
                    <!--begin::Page Custom Styles(used by this page) -->
                        <link href="assets/css/login-1.css" rel="stylesheet" type="text/css" />
                         <link href="assets/css/custom.css" rel="stylesheet" type="text/css" />
                    <!--end::Page Custom Styles -->
        
        <!--begin:: Global Mandatory Vendors -->
<link href="assets/vendors/general/css/perfect-scrollbar.css" rel="stylesheet" type="text/css" />


  <!-- bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- hover anmation -->
        
    <!-- main style -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- colors -->
    <link rel="stylesheet" href="assets/css/colors/main.css">

<!--begin::Global Theme Styles(used by all pages) -->
                    
    <link href="assets/css/style.bundle.css" rel="stylesheet" type="text/css" />
                <!--end::Global Theme Styles -->

        <!--begin::Layout Skins(used by all pages) -->
                <!--end::Layout Skins -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" integrity="sha256-ENFZrbVzylNbgnXx0n3I1g//2WeO47XxoPe0vkp3NC8=" crossorigin="anonymous" />		
	<style type="text/css">
		.error{
			border: 1px solid red;
		}
		.has-error{
			border: 1px solid red;
		}
	</style>
        
    </head>
    <!-- end::Head -->

    <!-- begin::Body -->
    <body>

                   <!-- begin::Page loader -->
	<?php include('header.php')?>
    <!-- // Header  -->
<!-- end::Page Loader -->        
    	<!-- begin:: Page -->
<div class="kt-grid kt-grid--ver kt-grid--root kt-page margin-left-100px  margin-right-100px">
	<div class="kt-grid kt-grid--hor kt-grid--root  kt-login kt-login--v1" id="kt_login ">
		<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--desktop kt-grid--ver-desktop kt-grid--hor-tablet-and-mobile margin-left-100px  margin-right-100px">
		

		<!--begin::Content-->
		<div class="kt-grid__item kt-grid__item--fluid  kt-grid__item--order-tablet-and-mobile-1  kt-login__wrapper">
			<!--begin::Head-->
			<!-- sign in form start -->
			<div class="kt-login__body" id="login">

				<!--begin::Signin-->
				<div class="kt-portlet">
					<div class="kt-portlet__head">
						<div class="kt-portlet__head-label">
							<h3 class="kt-portlet__head-title">
								Log In Here
							</h3>
						</div>
					</div>	
					<form action="loginctrl.php" method="post" class="kt-form" id="loginFrom">	
						<div class="form-group row">
							<div class="col-12">
								<div class="kt-radio-inline">
									<label class="kt-radio">
										<input type="radio" checked="" name="radio4" value="C"> Customer
										<span></span>
									</label>
									<label class="kt-radio">
										<input type="radio" name="radio4" value="R"> Restuarant
										<span></span>
									</label>
								</div>
							</div>
						</div>
						<!--begin::Form-->
					
						<div class="form-group">
							<input class="form-control ph_no" name="ph_no" type="text" placeholder="Mobile number as username"   maxlength="10">
						</div>
						<div class="form-group">
							<input class="form-control" name="password" type="password" placeholder="Password" id="pass" >
							<div class="col-lg-6 col-md-9 col-sm-12">
								<input type="checkbox" onclick="passFunction()">Show Password
							</div>
						</div>
						<!--begin::Action-->
						<div class="kt-login__actions">
							<button  type="submit" class="btn btn-primary btn-elevate kt-login__btn-primary login_button " name="login_button">Login</button>
						</div>
						<!--end::Action-->
					</form>
					<!--end::Form-->

					<!--begin::Divider-->
					<div class="kt-login__divider">
						<div class="kt-divider">
							<span></span>
							<span>OR</span>
							<span></span>
						</div>
					</div>
					<!--end::Divider-->

					<!--begin::Options-->
					<div class="kt-login__head btnsign">
						<span class="kt-login__signup-label">Don't have an account yet?</span>&nbsp;&nbsp;
						<a href="sign_up.php" id="signup" class="kt-link kt-login__signup-link">Sign Up!</a>
					</div>
					<!--end::Options-->
				</div>
				
				<!--end::Signin-->
			</div>
			<!-- sign in form ends -->
			
			
			<!--end::Body-->
		</div>
		<!--end::Content-->
	</div>
</div>
</div>
	
<!-- end:: Page -->




<!--begin:: Global Optional Vendors -->
<!--begin::Global Theme Bundle(used by all pages) -->    	    	   
<script src="assets/js/scripts.bundle.js" type="text/javascript"></script>

<script src="assets/js/login-1.js" type="text/javascript"></script>
<!--end::Page Scripts -->

<!--custom js ends-->

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js" integrity="sha256-sPB0F50YUDK0otDnsfNHawYmA5M0pjjUf4TvRJkGFrI=" crossorigin="anonymous"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js" integrity="sha256-3blsJd4Hli/7wCQ+bmgXfOdK7p/ZUMtPXY08jmxSSgk=" crossorigin="anonymous"></script>
	
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/imagesloaded.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script type="text/javascript">
       
        $('.ph_no').bind('keyup paste', function(){
            this.value = this.value.replace(/[^0-9]/g, '');
        });
        $("#loginFrom").validate({
			rules: {
				radio4: {
				  required: true,
				},
				ph_no: {
				  	required: true,
                    number: true,
                    maxlength: 10,
                    minlength: 10
				},
				password: {
					required: true
				},
			},
		    messages: {
		        //email: "Please enter a valid email address",
		        ph_no: {
		          required: "Please provide a registered phone number",
		          minlength: "Your phone number must be 10 characters long"
		        },
		        password: {
		          required: "Please provide a password",
		          minlength: "Your password must be at least 8 characters long",
		          equalTo: "Please enter the same password as above"
		        }
		    },
			errorPlacement: function(label, element) {
				//$('input').css("color", "red");
                //$('input').css("border", "1px solid red");
			},
			highlight: function(element, errorClass) {
				$(element).addClass('has-error');
				$(element).addClass('error');
			},
			unhighlight: function(element, errorClass, validClass) {
				$(element).removeClass('has-error');
				$(element).removeClass('error');
			},
			submitHandler: function(form) {
				var data = $('#loginFrom').serialize();
                var action = $('#loginFrom').attr('action');
				$.ajax({
					url:action,
					type: "POST",
					data: data,
					dataType: "json",
					success: function(result){
						if(result.error == 0){
							if(result.user_type == "R"){
								toastr.success('Login Success'); 
								setTimeout(function(){ 
									window.location.replace("menu.php");
								}, 2000);
							}else if(result.user_type == "C"){
								toastr.success('Login Success'); 
								setTimeout(function(){ 
									window.location.replace("menu.php");
								}, 2000);
							}
						}else{
							alert("Wrong Cradential !");
							//toastr.error('Wrong Cradential !');
						}
                    },
                    error: function(error){
                        console.log(error.responseText);
                    }
				});
			}
		});
    </script>
	<script>
		//view password
			function passFunction() {
			  var x = document.getElementById("pass");
			  
			  if (x.type  === "password") {
				x.type = "text";
			  } else {
				x.type = "password";
			  }
			}
	</script>

    </body>
    <!-- end::Body -->
</html>
