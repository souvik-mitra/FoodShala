<?php
$con = mysqli_connect("localhost","root","","foodshala");
session_start();
if (!$con) {
    die("Database connection failed");
}


?>

