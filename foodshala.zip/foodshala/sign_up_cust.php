


<!DOCTYPE html>
<html lang="en" >
    <!-- begin::Head -->
    <head>

        <title>Foodshala | Customer Sign Up </title>

        <!--begin::Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700">        <!--end::Fonts -->

        
		<!--begin::Page Custom Styles(used by this page) -->
		<link href="assets/css/login-1.css" rel="stylesheet" type="text/css" />
		<link href="assets/css/custom.css" rel="stylesheet" type="text/css" />
		<!--end::Page Custom Styles -->
		
		<!-- bootstrap -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<!-- hover anmation -->
		
		<!-- main style -->
		<link rel="stylesheet" href="assets/css/style.css">
		<!-- elegant icon -->
		<link href="assets/css/style.bundle.css" rel="stylesheet" type="text/css" />
	
    </head>
    <!-- end::Head -->


                   <!-- begin::Page loader -->
	
<!-- end::Page Loader -->        
    	<!-- begin:: Page -->
<body>

 <?php include('header.php')?>
    <!-- // Header  -->
		
<div class="kt-grid kt-grid--ver kt-grid--root kt-page margin-left-100px  margin-right-100px ">
	<div class="kt-grid kt-grid--hor kt-grid--root  kt-login kt-login--v1" id="kt_login">
		<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--desktop kt-grid--ver-desktop kt-grid--hor-tablet-and-mobile margin-left-100px  margin-right-100px">
		<!--begin::Aside-->
		<!--begin::Aside-->

		<!--begin::Content-->
		<div class="kt-grid__item kt-grid__item--fluid  kt-grid__item--order-tablet-and-mobile-1  kt-login__wrapper">
			<!--begin::Head-->
			
			<!--end::Head-->

			<!--begin::Body-->
			
			<div class="kt-login__body" id="regster">

				<!--begin::Signin-->
				<div class="kt-portlet ">
					<div class="kt-portlet__head">
						<div class="kt-portlet__head-label">
							<h3 class="kt-portlet__head-title">
								Register Here
							</h3>
						</div>
					</div>
					<!--begin::Form-->
					<form name="sign_up" action="Cust_Sign_upCtrl.php" method="POST" enctype="multipart/form-data" class="kt-form" id="reg" onsubmit="return Validate()">
						<div class="kt-portlet__body">
							<div class="kt-section kt-section--first">
								<!-- <h3 class="kt-section__title">1. Customer Info:</h3> -->
								<div class="kt-section__body">
									<div class="form-group row">
										<label class="col-lg-3 col-form-label">Enter Name:</label>
										<div class="col-lg-9"id="name_div">
											<input type="text" class="form-control" name="full_name" placeholder="Enter name">
											<div id="name_error"></div>
											
										</div>
									</div>
									
									
									<div class="form-group row kt-margin-t-20" >
										<label class="col-form-label col-lg-3 col-sm-12">Mobile Number<span class="form-text text-muted">As Username</span></label>
										
										<div class="col-lg-9 col-md-9 col-sm-12"id="number_div">
											<input class="listing-form ph_no" name="ph_no" type="text" value="" placeholder="Enter Mobile Number" id="example-tel-input" maxlength="10">
											<div id="number_error"></div>
										</div>
									</div>

									<div class="form-group row">
										<label class="col-lg-3 col-form-label">Email Id:</label>
										<div class="col-lg-9"id="email_div">
											<input type="text" class="form-control" name="email" placeholder="Enter Email id">
											<div id="email_error"></div>
										</div>
									</div>
									<div class="form-group row kt-margin-t-20" id="address">
										<label class="col-form-label col-lg-3 col-sm-12">Address</label>
										<div class="col-lg-9 col-md-9 col-sm-12" id="address_div">
											<input type="text" class="form-control" name="address" placeholder="Enter address"/>
											<div id="address_error"></div>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-3 col-form-label">Food Preference</label>
										<div class="col-9">
											<div class="kt-radio-inline">
												<label class="kt-radio">
													<input type="radio" name="radio4" checked="" value="0"> Veg
													<span></span>
												</label>
												<label class="kt-radio">
													<input type="radio" name="radio4" value="1"> Non-Veg
													<span></span>
												</label>
												<label class="kt-radio">
													<input type="radio" name="radio4" value="2"> Both
													<span></span>
												</label>
											</div>
										</div>
									</div>

									<div class="form-group row">
										<label for="example-password-input" class="col-form-label col-lg-3 col-sm-12">Password</label>
										<div class="col-lg-9 col-md-9 col-sm-12" id="password_div">
											<span class="form-text text-muted">* Password should contain atleast 8 characters and must have one small & one capital letter</span>
											<input class="form-control" name="password" type="password" value="" id="pass">
											<div id="password_error"></div>
											<div class="col-lg-6 col-md-9 col-sm-12">
											<input type="checkbox" onclick="passFunction()">Show Password
											</div>
											
										</div>
									</div>
									<div class="form-group row" >
										<label for="example-password-input" class="col-form-label col-lg-3 col-sm-12">Confirm Password</label>
										<div class="col-lg-9 col-md-9 col-sm-12"id="pass_confirm_div">
											<input class="form-control" type="password" name="crf_password" value="" id="c_pass" >
										<div id="crf_password_error"></div>
										<div class="col-lg-6 col-md-9 col-sm-12">
											<input type="checkbox" onclick="cpassFunction()">Show Password
											</div>
											
										</div>
										
									</div>
									
						<div class="kt-portlet__foot">
							<div class="kt-form__actions">
								<div class="row">
									<div class="col-lg-3"></div>
									<div class="col-lg-6">
										<button type="submit" name="submit" class="btn btn-success">Submit</button>
										<button type="reset" class="btn btn-secondary">Cancel</button>
									</div>
								</div>
							</div>
						</div>
						<div class="kt-login__head">
							<span class="kt-login__signup-label">Already have an account?</span>&nbsp;&nbsp;
							<a href="login.php" id="singin" class="kt-link kt-login__signup-link">Sign In!</a>
						</div>
					</form>
					<!--end::Form-->
				</div>
				
				<!--end::Signin-->
			</div>
			<!-- register form ends -->
			<!--end::Body-->
		</div>
		<!--end::Content-->
	</div>
</div>
</div>
	
<!-- end:: Page -->
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<!--end:: Global Mandatory Vendors -->

<!--custom js ends-->

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js" integrity="sha256-sPB0F50YUDK0otDnsfNHawYmA5M0pjjUf4TvRJkGFrI=" crossorigin="anonymous"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/imagesloaded.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
	<script src="assets/js/jquery-3.2.1.min.js"></script>
	<script>
	

        $('.ph_no').bind('keyup paste', function(){
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    </script>
	
	
        <script type="text/javascript">
		// SELECTING ALL TEXT ELEMENTS
		var full_name = document.forms['sign_up']['full_name'];
		var ph_no = document.forms['sign_up']['ph_no'];
		var email = document.forms['sign_up']['email'];
		var password = document.forms['sign_up']['password'];
		var crf_password = document.forms['sign_up']['crf_password'];
		var sign_as=document.forms['sign_up']['sign_as'];
		var address=document.forms['sign_up']['address'];
		var age=document.forms['sign_up']['age'];
		var letter =document.forms['sign_up'][/[a-zA-Z]/];
		var number =document.forms['sign_up'][/[0-9]/];
		var m_pattern =document.forms['sign_up'][/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,3})$/];
		// SELECTING ALL ERROR DISPLAY ELEMENTS
		var name_error = document.getElementById('name_error');
		var number_error = document.getElementById('number_error');
		var email_error = document.getElementById('email_error');
		var password_error = document.getElementById('password_error');
		var sign_as_error = document.getElementById('sign_as_error');
		var address_error = document.getElementById('address_error');
		var address_error = document.getElementById('age_error');
		// SETTING ALL EVENT LISTENERS
		full_name.addEventListener('blur', nameVerify, true);
		ph_no.addEventListener('blur', numberVerify, true);
		email.addEventListener('blur', emailVerify, true);
		password.addEventListener('blur', passwordVerify, true);
		sign_as.addEventListener('blur', sign_asVerify, true);
		address.addEventListener('blur', addressVerify, true);
		age.addEventListener('blur', ageVerify, true);
		// validation function
		function Validate() {
			// validate username
			  if (full_name.value == "") {
				full_name.style.border = "1px solid red";
				document.getElementById('name_div').style.color = "red";
				name_error.textContent = "Full name is required";
				full_name.focus();
				return false;
			  }
			  // validate phone number
			  if (ph_no.value == "") {
				full_name.style.border = "1px solid red";
				document.getElementById('number_div').style.color = "red";
				number_error.textContent = "Phone number is required";
				ph_no.focus();
				return false;
			  }
			  if (ph_no.value.length < 10) {
				ph_no.style.border = "1px solid red";
				document.getElementById('number_div').style.color = "red";
				number_error.textContent = "Phone number must contain 10 digits";
				ph_no.focus();
				return false;
			  }
			  // validate email
			  if (email.value == "") {
				email.style.border = "1px solid red";
				document.getElementById('email_div').style.color = "red";
				email_error.textContent = "Email is required";
				email.focus();
				return false;
			  }
			  // validate password
			if (password.value == "") {
				password.style.border = "1px solid red";
				document.getElementById('password_div').style.color = "red";
				crf_password.style.border = "1px solid red";
				password_error.textContent = "Password is required";
				password.focus();
				return false;
			  }
			  // check if the two passwords match
			  if (password.value != crf_password.value) {
				password.style.border = "1px solid red";
				document.getElementById('pass_confirm_div').style.color = "red";
				 crf_password.style.border = "1px solid red";
				crf_password_error.innerHTML = "The two passwords do not match";
				return false;
			  }
			  //password condition checking
			   if(sign_up.password.value != "" && sign_up.password.value == sign_up.crf_password.value) {
			  if(sign_up.password.value.length < 6) {
				password.style.border = "1px solid red";
				document.getElementById('pass_confirm_div').style.color = "red";
				crf_password.style.border = "1px solid red";
				crf_password_error.innerHTML = ("Password must contain at least six characters!");
				sign_up.password.focus();
				return false;
			  }
			  re = /[0-9]/;
			  if(!re.test(sign_up.password.value)) {
				password.style.border = "1px solid red";
				document.getElementById('pass_confirm_div').style.color = "red";
				crf_password.style.border = "1px solid red";
				crf_password_error.innerHTML = ("password must contain at least one number (0-9)!");
				sign_up.password.focus();
				return false;
			  }
			  re = /[a-z]/;
			  if(!re.test(sign_up.password.value)) {
				password.style.border = "1px solid red";
				document.getElementById('pass_confirm_div').style.color = "red";
				crf_password.style.border = "1px solid red";
				crf_password_error.innerHTML = ("password must contain at least one lowercase letter (a-z)!");
				sign_up.password.focus();
				return false;
			  }
			  re = /[A-Z]/;
			  if(!re.test(sign_up.password.value)) {
				password.style.border = "1px solid red";
				document.getElementById('pass_confirm_div').style.color = "red";
				crf_password.style.border = "1px solid red";
				crf_password_error.innerHTML = ("password must contain at least one uppercase letter (A-Z)!");
				sign_up.password.focus();
				return false;
			  }
			   }
			   //email verification
            if (m_pattern.test(sign_up.email.value) == false) 
            {
				document.getElementById('email_div').style.color = "red";
				email.style.border = "1px solid red";
				email_error.innerHTML = "Invalid e-mail Id";
				email.focus();
				
				return false;
                
            }
 
			
			  
			  //sign up as radio button validation
			  for(i=0;i<sign_as.length;i++){
			  if (sign_as[i].checked==true)
					return true;
			  }
			  document.getElementById('sign_as_div').style.color = "red";
				sign_as_error.innerHTML = "Please sign up as one of the above";
				return false;
			 // validate address
			  if (address.value == "") {
				address.style.border = "1px solid red";
				document.getElementById('address_div').style.color = "red";
				address_error.textContent = "Address is required";
				address.focus();
				return false;
			  }
			  //validate age
			  if (p_age.value == "") {
				p_age.style.border = "1px solid red";
				document.getElementById('age_div').style.color = "red";
				age_error.textContent = "Age is required";
				p_age.focus();
				return false;
			  }
			  
			  
		}
		
		
				
			  //event handler functions
			  function nameVerify() {
			  if (full_name.value != "") {
			   full_name.style.border = "1px solid #5e6e66";
			   document.getElementById('name_div').style.color = "#5e6e66";
			   name_error.innerHTML = "";
			   return true;
			  }
			}
			function numberVerify() {
			  if (ph_no.value != "") {
			   ph_no.style.border = "1px solid #5e6e66";
			   document.getElementById('number_div').style.color = "#5e6e66";
			   number_error.innerHTML = "";
			   return true;
			  }
			}
			function emailVerify() {
			  if (email.value != "") {
				email.style.border = "1px solid #5e6e66";
				document.getElementById('email_div').style.color = "#5e6e66";
				email_error.innerHTML = "";
				return true;
			  }
			}
			function passwordVerify() {
			  if (password.value != "") {
				password.style.border = "1px solid #5e6e66";
				document.getElementById('pass_confirm_div').style.color = "#5e6e66";
				document.getElementById('password_div').style.color = "#5e6e66";
				password_error.innerHTML = "";
				return true;
			  }
			  if (password.value === crf_password.value) {
				password.style.border = "1px solid #5e6e66";
				document.getElementById('pass_confirm_div').style.color = "#5e6e66";
				password_error.innerHTML = "";
				return true;
			  }
			}
			function sign_asVerify() {
			  if (sign_as[i].checked==true) {
			   sign_as.style.border = "1px solid #5e6e66";
			   document.getElementById('sign_as_div').style.color = "#5e6e66";
			   sign_as_error.innerHTML = "";
			   return true;
			  }
			}
			function addressVerify() {
			  if (address.value != "") {
				address.style.border = "1px solid #5e6e66";
				document.getElementById('address_div').style.color = "#5e6e66";
				address_error.innerHTML = "";
				return true;
			  }
			}
			function ageVerify() {
			  if (age.value != "") {
				address.style.border = "1px solid #5e6e66";
				document.getElementById('age_div').style.color = "#5e6e66";
				age_error.innerHTML = "";
				return true;
			  }
			}
			//view password
			function passFunction() {
			  var x = document.getElementById("pass");
			  
			  if (x.type  === "password") {
				x.type = "text";
			  } else {
				x.type = "password";
			  }
			}
			function cpassFunction() {
			var y = document.getElementById("c_pass");
			if (y.type  === "password") {
				y.type = "text";
			  } else {
				y.type = "password";
			  }
			}
		

		</script>
		


            </body>
    <!-- end::Body -->
</html>
