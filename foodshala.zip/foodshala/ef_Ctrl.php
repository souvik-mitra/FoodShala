<?php
	require_once './connection.php';

	if(isset($_POST["submit"])){
		$update = mysqli_query($con,"UPDATE tbl_cust_reg SET name='".$_POST['full_name']."',address='".$_POST['address']."',preference='".$_POST['radio4']."'
		WHERE id = '".$_SESSION['user_id']."'");
		if($update){
			header("Location: menu.php");
			
		}
	}
	

	
?>