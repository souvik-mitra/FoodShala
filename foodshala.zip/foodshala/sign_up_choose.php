


<!DOCTYPE html>
<html lang="en" >
    <!-- begin::Head -->
    <head>
        

        <title>Foodshala | Choose Sign Up </title>
        

        <!--begin::Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700">        <!--end::Fonts -->
		
		<!-- main style -->
		<link rel="stylesheet" href="assets/css/style.css">

		<!-- elegant icon -->
		<link href="assets/css/style.bundle.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="assets/css/custom_button.css">
		
	
    </head>
    <!-- end::Head -->      
    	<!-- begin:: Page -->
<body>

 <?php include('header.php')?>
    <!-- // Header  -->
	<div >
		<div  id="choose">
			<div class=" margin-left-100px  margin-right-100px">
				<div>
					<div class=" padding-200px margin-left-100px">
							<u><h2 class="margin-left-100px">
								Sign Up As
							</h2></u>
	
						<div class="padding-top-30px">
							<a href="sign_up_cust.php">
							<button type="button" id="custom-button"><b>CUSTOMER</b></button></a>
							<a href="sign_up_rest.php">
							<button type="button" id="custom-button" class="margin-left-30px"><b>RESTUARANT</b></button></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<!-- end:: Page -->
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<!--end:: Global Mandatory Vendors -->

<!--custom js ends-->

	
    
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/imagesloaded.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/custom.js"></script>
    
	

            </body>
    <!-- end::Body -->
</html>
