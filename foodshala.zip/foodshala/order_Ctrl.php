<?php
require_once './connection.php';

if(isset($_REQUEST['submit'])){
	
	$user_id = $_SESSION['user_id'];
	$array = [];
	$data = [];
	$cart_insert = '';
	$array = array_combine($_REQUEST['menu_array'],$_REQUEST['qty_array']);
	foreach($array as $key => $value){
		$cart_insert = mysqli_query($con, "insert into tbl_cart (fk_user_id,fk_add_menu_id,qty) values ('".$user_id."','".$key."','".$value."') ");
	}
	if($cart_insert){
		$data = ['error'=>0];
	}else{
		$data = ['error'=>1];
	}
	echo json_encode($data);
}
?>