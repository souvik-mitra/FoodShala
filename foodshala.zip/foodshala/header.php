<?php
require_once './connection.php';
$name = '';
if(isset($_SESSION['user_type'])){
if($_SESSION['user_type'] == "R"){
	$qry = "SELECT name FROM tbl_rest_reg WHERE id='".$_SESSION['user_id']."' ";
}
else{
	$qry = "SELECT name FROM tbl_cust_reg WHERE id='".$_SESSION['user_id']."' ";
}

$value = mysqli_query($con,$qry);
$data = mysqli_fetch_assoc($value);
$name = $data['name'];
}

?>

<header>
    <div id="fixed-header-dark" class="header-output fixed-header">
        <div class="container header-in">

            <div class="row">
                <div class="col-lg-2 col-md-12">
                    <a id="logo" href="index.php" class="d-inline-block margin-tb-15px"><img src="assets/img/icon/logo.png" alt=""></a>
					
                    <a class="mobile-toggle padding-13px background-main-color" href="#"><i class="fas fa-bars"></i></a>
                </div>
                <div class="col-lg-10 col-md-12 position-inherit">
                    <ul id="menu-main" class="nav-menu float-lg-right link-padding-tb-20px">
                        <li><a  href="menu.php">Menu</a></li>
                        
						
						<?php
							if(isset($_SESSION['user_type'])){
							if($_SESSION['user_type'] == "C"){
						?>
								<li><a href="edit_profile.php"> Edit Profile</a></li>
								<li><a href="cart.php">Cart</a></li>
						<?php
							}
							}
							if(isset($_SESSION['user_type'])){
							if($_SESSION['user_type'] == "R"){
						?>
								<li><a href="add_menu_item.php">Add item</a></li>
								<li><a href="view_order.php">View Orders</a></li>
						<?php
							}
							}
							if(isset($_SESSION['user_id'])){
							if(isset($_SESSION['user_id'])){
						?>
						<li><a href="javascript:;"> <?php echo $name; ?></a></li>
                        <li><a href="logoutCtrl.php"><i class="far fa-user"></i>Logout</a></li>
						<?php 
							}
							}else{
						?>
								<li><a href="login.php">Login</a></li>
								<li><a href="sign_up_choose.php"> Sign up</a></li>
							<?php }?>
						
                    </ul>
                </div>
            </div>

        </div>
    </div>
</header>