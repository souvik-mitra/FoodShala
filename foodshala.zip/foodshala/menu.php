<?php
require_once './connection.php';
$qry10 = mysqli_query($con,"SELECT * FROM tbl_rest_reg");
?>

<!DOCTYPE html>
<html lang="en-US">


<head>
    <title>Foodshala | Menu</title>
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7Chttps://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7CPoppins:300i,300,400,700,400i,500%7CDancing+Script:700%7CDancing+Script:700" rel="stylesheet">
    
    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- hover anmation -->
    <link rel="stylesheet" href="assets/css/hover-min.css">
    <!-- main style -->
    <link rel="stylesheet" href="assets/css/style.css">
	
	

    <!-- jquery library  -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <style>
	section.scroll {
	  width: 100%;
	  height: 700px;
	  overflow: auto;
	}
	</style>



</head>

<body>

    <?php include('header.php')?>
    <!-- // Header  -->
	
    <section class="banner sm-ptb-80px background-overlay scroll" style="padding-top:8% !important;">
        <div class="container z-index-2 position-relative">
            <div class="title padding-left-150px">
                <h2 class="text-title-medium text-main-color font-weight-300 margin-bottom-15px padding-left-150px">Feeling Hungry? . . .Order the best food online</h2>
                <h4 class="font-weight-300 text-main-color text-up-small margin-bottom-15px padding-left-300px">Find the best restuarants here</h4>
            </div>
            
			<?php 
				$count = mysqli_num_rows($qry10);
				if($count == 0){
			?>
			<div class="row" id="no_result_div">
				<h2 class="text-title-medium text-grey-color font-weight-300 margin-top-70px padding-left-250px">Oops! There are no restuarants available right now.</h2>
			</div>
			<?php 
				}
			while($row = mysqli_fetch_assoc($qry10))
			{ 
				if($row['photo']=='' || $row['photo']==null)
				{
					$img = 'image_upload/a.jpg';
				}else{
					$img = 'image_upload/'.$row['photo'];
				}
			
?>
			<div class="row" id="info_div ">
                <div class="col-lg-12 sm-mb-45px padding-top-50px padding-left-170px">
                    <div class="background-white thum-hover box-shadow hvr-float full-width margin-bottom-45px">
                        <div class="float-lg-left margin-right-30px sm-mr-0px text-center sm-mt-35px">
                            <img src="<?php echo $img;?>" class="img-rounded" width="265" height="230" alt="">
                        </div>
                        <div class="padding-lr-25px padding-tb-25px">
                            <a class="d-block text-dark text-medium margin-bottom-5px" href="javascript:;"><?php echo $row['name'];?></a>
							<a class="d-block text-dark text-medium margin-bottom-5px" href="javascript:;">Address: <?php echo $row['address'];?></a>
                            <p class="margin-top-15px text-grey-2"><?php echo $row['description'];?></p>
                            <div class="row ">
                                <div class="col-lg-12 text-center">
                                    <a href="view_dishes.php?id=<?php echo $row['id'];?>"><button id="dish" class="btn btn-md border-0 border-radius-10 background-main-color padding-lr-20px text-white margin-tb-10px">View Dishes</button></a>
								</div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
					
					</div>
			
				</div>
                    
                
            </div>
			<?php 
			}
			?>
			
			
        </div>
                       
    </section>
			
	

 <?php include('footer.php')?>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/imagesloaded.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/custom.js"></script>
	<script type="text/javascript">


        $('#amount').bind('keyup paste', function(){
            this.value = this.value.replace(/[^1-9]/g, '');
        });
    </script>
	
    
	
</body>



</html>
