<?php
	require_once './connection.php';
	

	$phone_no=$_POST["ph_no"];
	$password=$_POST["password"];
	$user_type=$_POST["radio4"];
	$result = [];

	if(isset($_REQUEST["login_button"]))
	{
		$qry = "SELECT * 
				FROM tbl_login WHERE username = '".$phone_no."' AND password = '".$password."' AND user_type = '".$user_type."' ";
		$data = mysqli_query($con, $qry);
		$array = mysqli_fetch_assoc($data);
		$array1 = mysqli_num_rows($data);
		if($array1 > 0){
			$_SESSION['user_id'] = $array['fk_user_id'];
			$_SESSION['user_type']=$user_type;
			$_SESSION['user_ph_no']=$phone_no;
			
			$result = ['user_type'=>$user_type,'error'=>0];
		}
		else{
			$result = ['error'=>1];
		}
		echo json_encode($result);
	}
?>