<!DOCTYPE html>
<html lang="en-US">


<head>
    <title>Foodshala</title>
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7Chttps://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7CPoppins:300i,300,400,700,400i,500%7CDancing+Script:700%7CDancing+Script:700" rel="stylesheet">
    
    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    
    <!-- main style -->
    <link rel="stylesheet" href="assets/css/style.css">
    
	
	<link rel="stylesheet" href="assets/css/slider.css">

    <!-- jquery library  -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
   



</head>

<body>

    <?php include('header.php')?>
    <!-- // Header  -->

    
				<!-- Slideshow container -->
				<div class="slideshow-container padding-top-100px"  >

				  <!-- Full-width images with number and caption text -->
				  <div class="mySlides fade" >
					<img src="slider/pic1.jpg" width="2000" height="550">
				  </div>

				  <div class="mySlides fade" >
					<img src="slider/pic2.jpg" width="2000" height="550">
				  </div>

				  <div class="mySlides fade" >
					<img src="slider/pic3.jpg" width="2000" height="550">
				  </div>
				  
				  <div class="mySlides fade">
					<img src="slider/pic4.jpg" width="2000" height="550">
				  </div>
				  
				  <div class="mySlides fade">
					<img src="slider/pic5.jpg" width="2000" height="550">
				  </div>
				  
				  <div class="mySlides fade">
					<img src="slider/pic6.jpg" width="2000" height="550">
				  </div>

				  
				</div>
				
		</div>
	</section>
	
    <section class="padding-tb-100px">
	
        <div class="container">

            <div class="row">

                

            </div>

        </div>
    </section>

    
	
	


    


    <?php include('footer.php')?>
    
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/imagesloaded.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/custom.js"></script>
    
    
	<script>
		var slideIndex = 0;
		showSlides();

		function showSlides() {
		  var i;
		  var slides = document.getElementsByClassName("mySlides");
		  for (i = 0; i < slides.length; i++) {
			slides[i].style.display = "none";
		  }
		  slideIndex++;
		  if (slideIndex > slides.length) {slideIndex = 1}
		  slides[slideIndex-1].style.display = "block";
		  setTimeout(showSlides, 5000); // Change image every 5 seconds
		}
		
	</script>
	
</body>



</html>
