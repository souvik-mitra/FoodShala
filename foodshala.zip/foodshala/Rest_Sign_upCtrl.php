<?php
require_once './connection.php';
if(isset($_POST["submit"]))
{
	$name=$_POST["rest_name"];
	$address=$_POST["rest_address"];
	$email=$_POST["rest_email"];
	$phone_no=$_POST["rest_ph_no"];
	$password=$_POST["rest_password"];
	$description=$_POST["rest_desc"];
	$phone_no_check=mysqli_query($con, "select * from tbl_rest_reg where phone_no='".$phone_no."' ");
	$count_ph_no = mysqli_num_rows($phone_no_check);
	if($count_ph_no > 0)
	{
		header("Location: sign_up_choose.php");
	}else{
		// file upload start
		$file_name = '';
		if(isset($_FILES['dp'])){
			$errors= array();
			$rand = rand(1000,9999);
			$file_name = $rand."_".$_FILES['dp']['name'];
			$file_size =$_FILES['dp']['size'];
			$file_tmp =$_FILES['dp']['tmp_name'];
			$file_type=$_FILES['dp']['type'];
			$file_ext=strtolower(end(explode('.',$_FILES['dp']['name'])));
		  
			$extensions= array("jpeg","jpg","png");
		  
			if(in_array($file_ext,$extensions)=== false){
				$errors[]="extension not allowed, please choose a JPEG or PNG file.";
			}
		  
			if($file_size > 2097152){
				$errors[]='File size must be excately 2 MB';
			}
		  
			if(empty($errors)==true){
				move_uploaded_file($file_tmp,"image_upload/".$file_name);
			}
		}
		// file upload end
		$insert = mysqli_query($con, "insert into tbl_rest_reg(name,phone_no,email,photo,address,description)values('".$name."','".$phone_no."','".$email."','".$file_name."','".$address."','".$description."')"); 
		$id = mysqli_insert_id($con);
	}
	//enter data for login page
	if($insert){  
		$insert2 = mysqli_query($con, "insert into tbl_login(fk_user_id,username,password,user_type)values('".$id."','".$phone_no."','".$password."','R')"); 
		if($insert2){
			header("Location: login.php");
		}
	}
	
	



}

?>