
<?php
require_once './connection.php';
$qry2 = mysqli_query($con,"SELECT tbl_cart.qty,tbl_add_menu.*
							FROM tbl_cart JOIN tbl_add_menu ON tbl_cart.fk_add_menu_id=tbl_add_menu.id 
							WHERE tbl_cart.fk_user_id='".$_SESSION['user_id']."' ");
?>



<!DOCTYPE html>
<html lang="en-US">



<head>
    <title>Foodshala | Cart</title>
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7Chttps://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7CPoppins:300i,300,400,700,400i,500%7CDancing+Script:700%7CDancing+Script:700" rel="stylesheet">
    <!-- owl Carousel assets -->
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- hover anmation -->
    <link rel="stylesheet" href="assets/css/hover-min.css">
    <!-- main style -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- jquery library  -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
</head>

<body>

    <?php include('header.php')?>
    <!-- // Header  -->
<section class="banner sm-ptb-80px background-overlay" style="padding-top:7% !important;">
        <div class="container z-index-2 position-relative">
			<div class="row" id="info_div ">
                <div class="col-lg-12 sm-mb-45px padding-left-170px">
					<?php 
						$count = mysqli_num_rows($qry2);
						if($count == 0){
					?>
					<div class="row" id="no_result_div" style="margin-bottom:24% !important;">
						<h2 class="text-title-medium text-grey-color font-weight-300 margin-bottom-70px padding-left-250px">Your Cart Is Empty..!</h2>
					</div>
					<?php 
						}else{
					?>
                    <div class="background-white thum-hover box-shadow hvr-float full-width margin-bottom-45px" style="margin-bottom:20% !important;">
						
						<div id="dish_div" >
						
							<form id="order_place" action="place_orderCtrl.php" method = "POST">
								<div  class="row padding-top-50px">
					
									<div  class="col-lg-12 ">
										<label class="col-lg-3 col-form-label padding-left-80px"><b><u>Restuarant Name</u></b></label>
										<label class="col-lg-3 col-form-label padding-left-70px"><b><u>Ordered Dishes</u></b></label>
										<label class="col-lg-2 col-form-label padding-left-130px"><b><u>Quantity</u></b></label>
										<label class="col-lg-2 col-form-label padding-left-160px"><b><u>Price</u></b></label>
									</div>
									<?php 
										while($data = mysqli_fetch_assoc($qry2)){
											$qry3 = mysqli_query($con, "SELECT name FROM tbl_rest_reg WHERE id = '".$data['fk_rest_id']."'");
											$rest_name = mysqli_fetch_assoc($qry3);
											
											$t_item_price = ($data['qty'] * $data['price']);
									?>
										<div class="row col-lg-12 ">
											<div class="col-lg-3 padding-left-100px padding-top-20px ">
												<a class="text-dark text-medium margin-bottom-5px" href="#"><?php echo $rest_name['name'];?></a>
											</div>
											<div class="col-lg-3 padding-left-100px padding-top-20px ">
												<a class="text-dark text-medium margin-bottom-5px" href="#"><?php echo $data['menu_name'];?></a>
											</div>
											<div class="col-lg-3 padding-left-160px padding-top-20px ">
												<input type="text" class="form-control" id="amount" value="<?php echo $data['qty'];?>" name="amount" disabled maxlength="1" >
											</div>
											<div class="col-lg-2 padding-left-110px padding-top-20px ">
												<a class=" text-dark text-medium margin-bottom-5px" href="#"><?php echo $t_item_price; ?></a>
											</div>
											<input type="hidden" name="rest_id[]" value="<?php echo $data['fk_rest_id']; ?>">
											<input type="hidden" name="qty[]" value="<?php echo $data['qty']; ?>">
											<input type="hidden" name="menu_id[]" value="<?php echo $data['id']; ?>">
										</div>
									<?php 
										} 
									?>
								</div>
								<div class="row ">
									<div class="col-lg-12 text-center padding-top-10px">
									<a href="success.php">
										<button class="btn btn-md border-0 border-radius-10 background-main-color padding-lr-20px text-white margin-tb-10px margin-bottom-30px" type="submit">Place Order</button></a>
									</div>
								</div>
							</form>
							
						</div>
							
					</div>
					<?php } ?>
				</div>
            </div>
        </div>        
    </section>
				<?php  include('footer.php')?>	
<!-- end:: Page -->
			
			
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js" integrity="sha256-sPB0F50YUDK0otDnsfNHawYmA5M0pjjUf4TvRJkGFrI=" crossorigin="anonymous"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/imagesloaded.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/custom.js"></script>
	<script src="assets/js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript">


        $('#price').bind('keyup paste', function(){
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    </script>
</body>
</html>