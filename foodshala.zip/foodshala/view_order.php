<?php
require_once './connection.php';

if(empty($_SESSION['user_id']))
{
	echo "<script>window.location.href='index.php'</script>";
}

$row = mysqli_query($con,"SELECT * FROM tbl_order WHERE fk_rest_id='".$_SESSION['user_id']."' GROUP BY fk_user_id");
//$data = mysqli_fetch_assoc($qry);
//echo"<pre>";
//print_r($data);die;

?>



<!DOCTYPE html>
<html lang="en-US">



<head>
    <title>Foodshala | View Order</title>
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7Chttps://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7CPoppins:300i,300,400,700,400i,500%7CDancing+Script:700%7CDancing+Script:700" rel="stylesheet">
    <!-- owl Carousel assets -->
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- hover anmation -->
    <link rel="stylesheet" href="assets/css/hover-min.css">
    <!-- main style -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- jquery library  -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
	


</head>

<body>

    <?php include('header.php')?>
    <!-- // Header  -->
	<?php
	while($data = mysqli_fetch_assoc($row)){
		$qry2=mysqli_query($con,"SELECT name,address FROM tbl_cust_reg WHERE id = '".$data['fk_user_id']."'");
		$data2=mysqli_fetch_assoc($qry2);
		$qry3=mysqli_query($con,"SELECT tbl_order.qty,tbl_order.order_date_time,tbl_add_menu.menu_name,tbl_add_menu.price FROM tbl_order JOIN tbl_add_menu ON tbl_order.fk_menu_id=tbl_add_menu.id WHERE tbl_order.fk_user_id='".$data['fk_user_id']."'");
	?>
<section class="banner sm-ptb-80px background-overlay" style="padding-top:6% !important;">
        <div class="container z-index-2 position-relative">
			<div class="row" id="info_div ">
                <div class="col-lg-12 sm-mb-45px padding-left-170px">
                    <div class="background-white thum-hover box-shadow hvr-float full-width margin-bottom-45px">
                        
                        
						
						<div id="view_order_div" >
							<div  class="row">
				
								<div  class="col-lg-12 padding-left-120px">
									<h4><label class="col-lg-10 col-form-label padding-left-250px"><b><u>Customer Details</u></b></label></h4>
								</div>
								<div class="padding-lr-25px padding-tb-25px padding-left-300px">
									<a class="d-block text-dark text-medium margin-bottom-5px" href="#">Name:&nbsp; <?php echo $data2['name'];?></a>
									<div class="d-block padding-tb-5px">  <a href="javascript:void(0)">Address: &nbsp; <?php echo $data2['address'];?></a>
									</div>
									<div class="d-block padding-tb-5px">  <a href="javascript:void(0)">Date & time: <?php echo date("d-m-Y H:i a", strtotime($data['order_date_time'])) ;?></a>
									</div>
								</div>
								<div  class="col-lg-12 padding-left-130px ">
									<h4><label class="col-lg-10 col-form-label padding-left-250px"><b><u>Food Details</u></b></label></h4>
								</div>
								<div  class="row padding-top-50px">
				
									<div  class="form-group row col-lg-12">
										<label class="col-lg-8 col-md-8 padding-left-150px"><b><u>Ordered Dishes</u></b></label>
										<label class="col-lg-1 col-md-1"><b><u>Quantity</u></b></label>
										<label class="col-lg-3 col-md-3 padding-left-100px"><b><u>Price</u></b></label>
									</div>
									<?php
									while($value=mysqli_fetch_assoc($qry3)){
										$price=($value['qty']*$value['price']);
									?>
									<div class="form-group row col-lg-12">
											<div class="col-lg-8 col-md-8 padding-top-20px padding-left-150px">
												<a class="text-dark text-medium margin-bottom-5px" href="#"><?php echo $value['menu_name'];?></a>
											</div>
											<div class="col-lg-1 col-md-1 padding-top-20px">
												<input type="text" class="form-control" id="amount" name="amount" disabled value="<?php echo $value['qty'];?>" maxlength="1" >
											</div>
											<div class="col-lg-3 col-md-3 padding-left-100px padding-top-20px ">
												<a class=" text-dark text-medium margin-bottom-5px" href="#"><?php echo $price;?></a>
											</div>
										
									</div>
									<?php
									}
									?>
										
										
								</div>
								
							
							
							
							</div>
							<div class="clearfix"></div>
					
						</div>
						
			
					</div>
				</div>
			</div>
		</div>
                       
</section>
	<?php
	}
	?>

	 <?php include('footer.php')?>	
<!-- end:: Page -->
			
			<!--begin:: Global Mandatory Vendors -->
			<script src="assets/vendors/general/js/jquery.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/popper.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/js.cookie.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/moment.min.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/tooltip.min.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/perfect-scrollbar.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/sticky.min.js" type="text/javascript"></script>
<script src="assets/vendors/general/js/wNumb.js" type="text/javascript"></script>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js" integrity="sha256-sPB0F50YUDK0otDnsfNHawYmA5M0pjjUf4TvRJkGFrI=" crossorigin="anonymous"></script>
    <script src="assets/js/sticky-sidebar.js"></script>
    <script src="assets/js/YouTubePopUp.jquery.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/imagesloaded.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript">


        $('#price').bind('keyup paste', function(){
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    </script>
</body>
</html>