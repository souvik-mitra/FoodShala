<?php
require_once './connection.php';
if(empty($_SESSION['user_id']))
{
	echo "<script>window.location.href='index.php'</script>";
}
$user_id = $_SESSION['user_id'];
$qry = "SELECT *
				FROM tbl_cust_reg
				
				WHERE id='".$_SESSION['user_id']."' ";
$data = mysqli_query($con, $qry);
$user_details = mysqli_fetch_assoc($data);
//echo"<pre>";print_r($user_details);die;
?>



<!DOCTYPE html>
<html lang="en-US">



<head>
    <title>Foodshala | Edit Profile</title>
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7Chttps://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7CPoppins:300i,300,400,700,400i,500%7CDancing+Script:700%7CDancing+Script:700" rel="stylesheet">
    
    
    <!-- bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    
    <!-- main style -->
    <link rel="stylesheet" href="assets/css/style.css">
    
   
    
	


</head>

<body>

    <?php include('header.php')?>
    <!-- // Header  -->
<section class="banner padding-tb-20px sm-ptb-80px background-overlay" >
	<div class=" kt-grid kt-grid--ver kt-grid--root kt-page container z-index-2 position-relative">
		<div class="kt-grid kt-grid--hor kt-grid--root  kt-login kt-login--v1" id="kt_pf">
				<div class="kt-login__body" id="e_pf">

				<!--begin::Signin-->
				<div class="kt-portlet">
					
					<!--begin::Form-->
					<form name="sign_up" action="ef_Ctrl.php" method="POST" class="kt-form margin-top-70px" id="edit_pf" onsubmit="return Validate()">
						<div class="kt-portlet__body">
							<div class="kt-section kt-section--first">
							<label class="col-lg-10 col-form-label text-center"><h2><b><u><i>Edit Profile</i></u></h2></b></label>
								<!-- <h3 class="kt-section__title">1. Customer Info:</h3> -->
								<div class="kt-section__body margin-top-30px">
								
									<div class="form-group row">
										<label class="col-lg-24 col-form-label padding-left-300px"><b>Edit Name:</b></label>
										<div class="col-lg-4" id="name_div">
											<input type="text" class="form-control" name="full_name" placeholder="" value="<?php echo $user_details['name'];?>">
											<div id="name_error"></div>
											
										</div>
									</div>
									<div class="form-group row " >
										<label class="col-form-label col-lg-24  padding-left-300px"><b>Mobile Number:</b></label>
										
										<div class="col-lg-4 col-md-9 col-sm-12"id="number_div">
											<input class="listing-form ph_no" name="ph_no" type="text" disabled placeholder="" id="example-tel-input" maxlength="10" value="<?php echo $user_details['phone_no'];?>">
											<div id="number_error"></div>
										</div>
									</div>

									<div class="form-group row">
										<label class="col-lg-24 padding-left-300px col-form-label"><b>Email Id:</b></label>
										<div class="col-lg-4"id="email_div">
											<input type="text" class="form-control" name="email" disabled placeholder="" value="<?php echo $user_details['email'];?>">
											<div id="email_error"></div>
										</div>
									</div>

									
									<div class="form-group row " id="address" >
										<label class="col-form-label col-lg-24 padding-left-300px"><b>Edit Address:</b></label>
										<div class="col-lg-4 " id="address_div">
											<input type="text" class="form-control" name="address" value="<?php echo $user_details['address'];?>"/>
											<div id="address_error"></div>
										</div>
									</div>
									<div class="form-group row padding-left-285px">
										<label class="col-lg-12 col-form-label "><b>Edit Food Preference</b></label>
										<div class="col-9">
											<div class="kt-radio-inline">
												<label class="kt-radio">
													<input type="radio" name="radio4" checked="" value="0"> Veg
													<span></span>
												</label>
												<label class="kt-radio">
													<input type="radio" name="radio4" value="1"> Non-Veg
													<span></span>
												</label>
												<label class="kt-radio">
													<input type="radio" name="radio4" value="2"> Both
													<span></span>
												</label>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="kt-portlet__foot">
							<div class="kt-form__actions">
								<div class="row">
									<div class="col-lg-3"></div>
									<div class="col-lg-6">
										<button type="submit" name="submit" class="btn btn-success margin-left-100px">Update</button>
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="reset" class="btn btn-secondary">Cancel</button>
									</div>
								</div>
							</div>
						</div>
						
					</form>
					<!--end::Form-->
				</div>
			</div>
			<!--end::Content-->
		</div>
	
</div>
</section>

	
<!-- end:: Page -->
			
			



    
	
</body>
</html>