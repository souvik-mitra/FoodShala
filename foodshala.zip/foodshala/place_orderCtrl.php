<?php
require_once './connection.php';

foreach($_POST['rest_id'] as $key=>$val){
	
	$rec[$key]=array(
		'rest_id'=>$_POST['rest_id'][$key],
		'qty'=>$_POST['qty'][$key],
		'menu_id'=>$_POST['menu_id'][$key],
	);
}
date_default_timezone_set('Asia/Calcutta');
$date_time = date("Y-m-d H:i:s");
$insert = '';
foreach($rec as $key){
	$insert = mysqli_query($con, "insert into tbl_order(fk_rest_id,fk_user_id,fk_menu_id,qty,order_date_time)values('".$key['rest_id']."','".$_SESSION['user_id']."','".$key['menu_id']."','".$key['qty']."','".$date_time."')");
}
if($insert){
	mysqli_query($con, "DELETE FROM tbl_cart WHERE fk_user_id = '".$_SESSION['user_id']."' ");
	header("location: success.php");
}
?>